from django.contrib import admin
from chef.models import *
from post.models import *

admin.site.register(Ingredients)
admin.site.register(Recipes)
admin.site.register(RecipesCategory)
admin.site.register(IngredientsCategory)
admin.site.register(Post)
admin.site.register(Group)
admin.site.register(Clients)
admin.site.register(RecipesIngredients)
admin.site.register(Addresses)
admin.site.register(MessagesReceived)
admin.site.register(NewMessages)
