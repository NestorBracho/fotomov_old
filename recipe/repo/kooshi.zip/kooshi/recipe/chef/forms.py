#encoding:utf-8
import datetime
from django.forms import ModelForm
from django.db import models 
from django import forms
from django.contrib.auth.models import User
from chef.models import *
from django.contrib.admin.widgets import AdminDateWidget 
from django.forms.extras.widgets import SelectDateWidget
from django.forms.widgets import CheckboxSelectMultiple 

class ClientForm(forms.Form):
  billing_choices = (
    ('Daily', 'Daily'),
    ('Weekly', 'Weekly'),
    ('Monthly', 'Monthly'),
    ('Yearly', 'Yearly'),
    )  
  premium_choices = (
    ('No', 'No'),
    ('Yes', 'Yes'),
    )    
  name = forms.CharField()
  lastName = forms.CharField()
  apppassword = forms.CharField()
  email = forms.EmailField(required=False)
  primaryPhone = forms.CharField()
  homePhone = forms.CharField(required=False)
  homePhone2 = forms.CharField(required=False)
  movilPhone = forms.CharField(required=False)
  movilPhone2 = forms.CharField(required=False)
  premium = forms.ChoiceField(choices=premium_choices)
  billing = forms.ChoiceField(choices=billing_choices)
  amount = forms.CharField()

class RecipesForm(forms.Form):
  
  categorias = RecipesIngredients.objects.all()
  
  name = forms.CharField()
  description = forms.CharField(widget=forms.Textarea)
  image = forms.ImageField(required=False)
  category = forms.ModelChoiceField(queryset=RecipesCategory.objects.all(),required=False)
  category_new = forms.CharField(required=False)

class IngredientsForm(forms.Form):
  name = forms.CharField(max_length=100)
  price = forms.CharField(max_length=100)
  quantity = forms.IntegerField()
  unit = forms.CharField(max_length=100)
  category = forms.ModelChoiceField(queryset=IngredientsCategory.objects.all(),required=False)
  category_new = forms.CharField(required=False)

class Edit_IngredientsForm(forms.Form):
  name = forms.CharField(max_length=100)
  price = forms.CharField(max_length=100)
  quantity = forms.IntegerField()
  unit = forms.CharField(max_length=100)
  category = forms.ModelChoiceField(queryset=IngredientsCategory.objects.all(),required=False)
  category_new = forms.CharField(required=False)

class RecipesForm(forms.Form):  
  categorias = RecipesIngredients.objects.all()
  name = forms.CharField()
  description = forms.CharField(widget=forms.Textarea)
  image = forms.ImageField(required=False)
  category = forms.ModelChoiceField(queryset=RecipesCategory.objects.all(),required=False)
  category_new = forms.CharField(required=False)
  list_ingredients = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple(),
        required=False)

class GroupsForm(forms.Form):  
  name = forms.CharField()
  description = forms.CharField(widget=forms.Textarea)

class GroupsClientsForm(forms.Form):
  clients = forms.ModelMultipleChoiceField(queryset=Clients.objects.all(), widget=forms.CheckboxSelectMultiple(), required=False)

class Edit_RecipeForm(forms.Form):
  name = forms.CharField()
  description = forms.CharField(widget=forms.Textarea)
  image = forms.ImageField(required=False)
  category = forms.ModelChoiceField(queryset=RecipesCategory.objects.all(),required=False)
  category_new = forms.CharField(required=False)
  list_ingredients = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple(),
        required=False)

class AddRecipeForm(forms.ModelForm):
  category_new = forms.CharField(required=False)
  category_list = forms.ModelChoiceField(queryset=RecipesCategory.objects.all(),required=False)
  class Meta:
    model = Recipes
    exclude = {'list_ingredients','category','date'} 

class NewMessagesForm(forms.Form):
  delivery_date = forms.CharField(max_length=10) 
  hour = forms.CharField(max_length=10)

class ReplyForm(forms.ModelForm):
  class Meta:
    model = MessagesReceived
    exclude = ['date','income','user']


