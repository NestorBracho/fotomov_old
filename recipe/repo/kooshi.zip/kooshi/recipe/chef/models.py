#encoding:utf-8
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin

class IngredientsCategory(models.Model):
  name = models.CharField(max_length=30, unique=True)

  def __unicode__(self):
    return self.name

class Ingredients(models.Model):
  def __unicode__(self):
    return self.name

  name = models.CharField(max_length=100)
  price = models.CharField(max_length=100)
  quantity =  models.IntegerField()
  unit = models.CharField(max_length=10)
  category = models.ForeignKey(IngredientsCategory)


class Clients(models.Model):
  name = models.CharField(max_length=100)
  lastName = models.CharField(max_length=100)
  email = models.CharField(max_length=100,unique=True)
  apppassword = models.CharField(max_length=30)
  primaryPhone = models.CharField(max_length=100)
  homePhone = models.CharField(max_length=100,null=True,blank=True)
  homePhone2 = models.CharField(max_length=100,null=True,blank=True)
  movilPhone = models.CharField(max_length=100,null=True,blank=True)
  movilPhone2 = models.CharField(max_length=100,null=True,blank=True)
  billing = models.CharField(max_length=7)
  amount = models.IntegerField()
  premium = models.CharField(max_length=30,default='No')
  def __unicode__(self):
    return self.name


class Addresses(models.Model):
  client = models.ForeignKey(Clients)
  addr = models.CharField(max_length=100)
  x = models.FloatField()
  y = models.FloatField()

class RecipesCategory(models.Model):
  name = models.CharField(max_length=30, unique=True)

  def __unicode__(self):
    return self.name

class RecipesIngredients(models.Model):
  ingredient = models.ForeignKey(Ingredients)
  recipe = models.CharField(max_length=100)
  quantity = models.IntegerField()
  unit = models.CharField(max_length=10)

class Recipes(models.Model):
  name = models.CharField(max_length=100,unique=True)
  description = models.TextField(max_length=200)
  image = models.ImageField(upload_to='cargas',null=True,blank=True)
  category = models.ForeignKey(RecipesCategory)
  date = models.CharField(max_length=10)
  list_ingredients = models.ManyToManyField(RecipesIngredients, null=True)

class Group(models.Model):
  name =  models.CharField(max_length=100,unique=True)
  client = models.ManyToManyField(Clients)
  description = models.CharField(max_length=300)
  number = models.IntegerField(default=0)
  
class NewMessages(models.Model):
  name_user = models.ManyToManyField(Clients, null=True)
  name_recipe = models.ForeignKey(Recipes)
  date = models.CharField(max_length=10) 
  delivery_date = models.CharField(max_length=10) 
  hour = models.CharField(max_length=10)

class MessagesReceived(models.Model):
  title = models.CharField(max_length=100)
  message = models.TextField(max_length=300)
  user = models.ForeignKey(Clients)
  income = models.BooleanField(default=True)
  date = models.CharField(max_length=10)

# Create your models here.
