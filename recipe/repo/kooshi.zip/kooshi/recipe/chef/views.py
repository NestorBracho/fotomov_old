from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext, loader
from django.contrib.auth.decorators import login_required
from chef.models import *
from chef.forms import *
from datetime import datetime
from django.core.mail import EmailMessage, EmailMultiAlternatives
from django.core.urlresolvers import reverse
from django.forms.formsets import formset_factory
from django import forms
from gmapi import maps
from gmapi.forms.widgets import GoogleMap
from gmapi.maps import Geocoder

class MapForm(forms.Form):
  map = forms.Field(widget=GoogleMap(attrs={'width': 510, 'height': 510}))


def clients(request):
  lista = Clients.objects.all()

  if request.method=='POST':
    formulario = ClientForm(request.POST)
    if formulario.is_valid():
      cliente = Clients.objects.create(name=formulario.cleaned_data['name'],
                                       lastName=formulario.cleaned_data['lastName'],
                                       email=formulario.cleaned_data['email'],
                                       apppassword = formulario.cleaned_data['apppassword'],
                                       primaryPhone=formulario.cleaned_data['primaryPhone'],
                                       homePhone=formulario.cleaned_data['homePhone'],
                                       homePhone2=formulario.cleaned_data['homePhone2'],
                                       movilPhone=formulario.cleaned_data['movilPhone'],
                                       movilPhone2=formulario.cleaned_data['movilPhone2'],
                                       billing=formulario.cleaned_data['billing'],
                                       amount=formulario.cleaned_data['amount'],
                                       premium=formulario.cleaned_data['premium'])
      cliente.save()

      redireccion = '/address/' + str(cliente.id)
      return HttpResponseRedirect(redireccion)
  else:
    formulario = ClientForm()
  return render_to_response('client.html', {'formulario': formulario, 'lista': lista},
                            context_instance=RequestContext(request))

def profile(request, id_cliente):
  cliente = Clients.objects.get(pk=id_cliente)
  direcciones = Addresses.objects.filter(client=cliente)

  gmap = maps.Map(opts = {
    'center': maps.LatLng(38, -97),
    'mapTypeId': maps.MapTypeId.ROADMAP,
    'zoom': 3,
    'mapTypeControlOptions': {
      'style': maps.MapTypeControlStyle.DROPDOWN_MENU
    },
  })
  marker = maps.Marker(opts = {
    'map': gmap,
    'position': maps.LatLng(38, -97),
  })
  maps.event.addListener(marker, 'mouseover', 'myobj.markerOver')
  maps.event.addListener(marker, 'mouseout', 'myobj.markerOut')
  info = maps.InfoWindow({
    'content': 'Hello!',
    'disableAutoPan': True
  })
  info.open(gmap, marker)

  if request.method=='POST':

    formulario = ClientForm(request.POST)
    if formulario.is_valid():

      cliente.name = formulario.cleaned_data['name']
      cliente.lastName = formulario.cleaned_data['lastName']
      cliente.email = formulario.cleaned_data['email']
      cliente.primaryPhone = formulario.cleaned_data['primaryPhone']
      cliente.homePhone = formulario.cleaned_data['homePhone']
      cliente.homePhone2 = formulario.cleaned_data['homePhone2']
      cliente.movilPhone = formulario.cleaned_data['movilPhone']
      cliente.movilPhone2 = formulario.cleaned_data['movilPhone2']
      cliente.billing = formulario.cleaned_data['billing']
      cliente.amount = formulario.cleaned_data['amount']
      cliente.save()

      return HttpResponseRedirect('/clients')
  else:
    formulario = ClientForm(initial={'name': cliente.name, 'lastName': cliente.lastName, 'email': cliente.email,
                                     'primaryPhone': cliente.primaryPhone, 'homePhone': cliente.homePhone,
                                     'movilPhone': cliente.movilPhone, 'movilPhone2': cliente.movilPhone2,
                                     'billing': cliente.billing, 'amount': cliente.amount,'apppassword':cliente.apppassword,'premium':cliente.premium})
  return render_to_response('profile.html', {'direcciones': direcciones, 'cliente': cliente, 'formulario': formulario,
                                             'form': MapForm(initial={'map': gmap})},
                            context_instance=RequestContext(request))

def address(request, id_cliente):
  cliente = Clients.objects.get(pk=id_cliente)

  if request.method=='POST':

    formulario = request.POST.getlist('dir')
    i = 0
    while i < len(formulario):
      print formulario[i]
      print formulario[i+1]
      print formulario[i+2]
      direccion = Addresses.objects.create(client=cliente, addr=formulario[i], y=formulario[i+1], x=formulario[i+2])
      i += 3

      direccion.save()

    return HttpResponseRedirect('/clients')

  return render_to_response('address.html', {'cliente': cliente},
                            context_instance=RequestContext(request))

def login_page(request):
  if request.method == 'POST':
    formulario = AuthenticationForm(request.POST)
    if formulario.is_valid:
      usuario = request.POST['username']
      clave = request.POST['password']
      print usuario
      print clave
      acceso = authenticate(username=usuario, password=clave)
      if acceso is not None:
        if acceso.is_active:
          login(request,acceso)
          return HttpResponseRedirect('/post')
        else:
          formulario = AuthenticationForm()
          error_log = "you are not allow in my kitchen"
          return render_to_response('index.html',{'formulario':formulario,'error_log':error_log}, context_instance=RequestContext(request))
      else:
        formulario = AuthenticationForm()
        error_log = "incorret username or password"
        return render_to_response('index.html',{'formulario':formulario,'error_log':error_log}, context_instance=RequestContext(request))
  else:
    formulario = AuthenticationForm()
  return render_to_response('index.html',{'formulario':formulario}, context_instance=RequestContext(request))

@login_required(login_url='/')
def ingredientes(request):
  list_ingredients = Ingredients.objects.all()
  if request.method == 'POST':
    formulario = IngredientsForm(request.POST)
    if formulario.is_valid(): 
      if formulario.cleaned_data['category_new'] == "" :
        cat = formulario.cleaned_data['category']
      else:
        dato = formulario.cleaned_data['category_new']
        cat = IngredientsCategory.objects.create(name=dato)
      name = formulario.cleaned_data['name']
      price = formulario.cleaned_data['price']
      quantity = formulario.cleaned_data['quantity']
      unit = formulario.cleaned_data['unit']     
      ingrediente = Ingredients.objects.create(name=name,price=price,quantity=quantity,unit=unit,category=cat)
      ingrediente.save()
      return HttpResponseRedirect('/ingredients')   
  else:
    formulario = IngredientsForm()
  return render_to_response('ingredients.html',{'formulario':formulario, 'list_ingredients':list_ingredients},context_instance=RequestContext(request))

def edit_ingredients(request,id_item):
  formulario = AuthenticationForm(request.POST)
  ingred = Ingredients.objects.get(pk=id_item)
  if request.method == 'POST':
    formulario = Edit_IngredientsForm(request.POST)
    if formulario.is_valid():
      if formulario.cleaned_data['category_new'] == "" :
        cat = formulario.cleaned_data['category']
      else:
        dato = formulario.cleaned_data['category_new']
        cat = IngredientsCategory.objects.create(name=dato)
      ingred.name = formulario.cleaned_data['name']
      ingred.price = formulario.cleaned_data['price']
      ingred.quantity = formulario.cleaned_data['quantity']
      ingred.unit = formulario.cleaned_data['unit']
      ingred.category = cat
      ingred.save()
    return HttpResponseRedirect('/ingredients')
  else:
    formulario = Edit_IngredientsForm()
  list_ingredients = Ingredients.objects.all()
  return render_to_response('ingredients_edit.html',{'formulario_edit':formulario,'list_ingredients':list_ingredients,'id_ingredient':id_item},context_instance=RequestContext(request)) 

@login_required(login_url='/')
def ingredients_delete(request,id_item):
  print 'El id del ingrediente que se quiere eliminar es: ' + id_item
  b = Ingredients.objects.filter(pk=id_item).delete()
  return HttpResponseRedirect('/ingredients')

@login_required(login_url='/')
def all_recipes(request):
  list_recipes = Recipes.objects.all()
  return render_to_response('all_recipes.html',{'list_recipes':list_recipes},context_instance=RequestContext(request)) 

@login_required(login_url='/')
def recipes_edit(request,id_item):
  recipe = Recipes.objects.get(pk=id_item)
  name_recipe = recipe.name
  list_ingredients = Ingredients.objects.all()
  list_recipesIngredients = request.POST.getlist('lista')
  if request.method == 'POST':
    formulario = Edit_RecipeForm(request.POST,request.FILES) 
    if formulario.is_valid():
      if formulario.cleaned_data['category_new'] == "" :
        cat = formulario.cleaned_data['category']
      else:
        dato = formulario.cleaned_data['category_new']
        cat = RecipesCategory.objects.create(name=dato)
      recipe.name = formulario.cleaned_data['name']
      recipe.description = formulario.cleaned_data['description']
      recipe.image = formulario.cleaned_data['image']
      recipe.category = cat
      recipe.save()

      for name_ing in list_recipesIngredients:
        RecipesIngredients.objects.filter(recipe=name_recipe).delete()
        cant = request.POST.get(name_ing)    #Cantidad necesario del ingrediente
        obj_recipe = Recipes.objects.get(name=formulario.cleaned_data['name'])
        obj_ingred = Ingredients.objects.get(name = name_ing)
        #Creando RecipesIngredients
        item_ingre = RecipesIngredients.objects.create(ingredient = obj_ingred,recipe = formulario.cleaned_data['name'],quantity= cant)
        obj_recipe.list_ingredients.add(item_ingre)

    return HttpResponseRedirect('/allrecipes')   
  else:
    formulario = Edit_RecipeForm(initial={'name':recipe.name,'description':recipe.description,'image':recipe.image,'category':recipe.category})
  return render_to_response('recipes_edit.html',{'formulario':formulario,'list_ingredients':list_ingredients,'id_recipe':id_item},context_instance=RequestContext(request))

def groups(request):
  grupos = Group.objects.all()
  if request.method == 'POST':
    formulario = GroupsForm(request.POST)
    if formulario.is_valid:
      name = request.POST['name']
      print name
      description = request.POST['description']
      grupo = Group.objects.create(name=name,description=description)
      grupo.save()
      return HttpResponseRedirect('/groups')   
  else:
    formulario = GroupsForm()
  return render_to_response('groups.html',{'formulario':formulario,'grupos':grupos},context_instance=RequestContext(request))

def view_group(request,id_group):
  grupo = Group.objects.get(id=id_group)
  miembros = grupo.client.all()
  print grupo.client
  return render_to_response('view_group.html',{'grupo':grupo,'miembros':miembros},context_instance=RequestContext(request))

def edit_group(request,id_group):
  grupo = Group.objects.get(id=id_group)
  if request.method == 'POST':
    formulario = PostEditForm(request.POST,request.FILES)
    if formulario.is_valid():
      if formulario.cleaned_data['image'] == None:
        post.title = formulario.cleaned_data['title']
        post.post = formulario.cleaned_data['post']
        post.fecha = datetime.date.today()
        post.save()
      else:
        post.image.delete()
        post.title = formulario.cleaned_data['title']
        post.post = formulario.cleaned_data['post']
        post.fecha = datetime.date.today()
        post.save()
        post.image = formulario.cleaned_data['image']
        post.save()

    return HttpResponseRedirect('/groups')   
  else:
    clientes = grupo.client.all()
    clientesTotal = Clients.objects.all().exclude(id__in=clientes)
    print clientes
    formulario = GroupsForm(initial={'name':grupo.name,'description':grupo.description})
  return render_to_response('edit_group.html',{'formulario':formulario,'clientes':clientes,'grupo':grupo,'clientesTotal':clientesTotal},context_instance=RequestContext(request))

@login_required(login_url='/')
def add_group_member(request,id_miembro,id_grupo):
  grupo = Group.objects.get(pk=id_grupo)
  miembro = Clients.objects.get(pk=id_miembro)
  grupo.client.add(miembro)
  redireccion = '/edit_group/' + id_grupo
  return HttpResponseRedirect(redireccion)

@login_required(login_url='/')
def recipes_delete(request,id_item):
  print 'El id recipe que se quiere eliminar es: ' + id_item
  b = Recipes.objects.filter(pk=id_item).delete()
  return HttpResponseRedirect('/allrecipes')

@login_required(login_url='/')
def recipe(request):
  list_ingredients = Ingredients.objects.all()
  list_recipesIngredients = request.POST.getlist('lista')
  if request.method == 'POST':
    formulario = AddRecipeForm(request.POST,request.FILES)
    if formulario.is_valid():
      if formulario.cleaned_data['category_new'] == "" :
        cat = formulario.cleaned_data['category_list']
      else:
        dato = formulario.cleaned_data['category_new']
        cat = RecipesCategory.objects.create(name=dato)
      add = formulario.save(commit=False)
      add.category = cat

      today = datetime.now() #fecha actual
      dateFormat = today.strftime("%m/%d/%Y") # fecha con formato

      add.date = dateFormat
      add.save()      
      ##formulario.save_m2m()
      
      for name_ing in list_recipesIngredients:
        cant = request.POST.get(name_ing)    #Cantidad necesario del ingrediente
        obj_recipe = Recipes.objects.get(name=formulario.cleaned_data['name'])
        obj_ingred = Ingredients.objects.get(name = name_ing)
        #Creando RecipesIngredients
        item_ingre = RecipesIngredients.objects.create(ingredient = obj_ingred,recipe = formulario.cleaned_data['name'],quantity= cant)
        obj_recipe.list_ingredients.add(item_ingre)
              
      	print 'El ingrediente ' + name_ing + ' con cantidad ' + cant

      return HttpResponseRedirect('/recipes')
  else:
    formulario = AddRecipeForm()
  return render_to_response('recipe.html',{'formulario':formulario, 'list_ingredients':list_ingredients}, context_instance=RequestContext(request))

@login_required(login_url='/')
def delete_group_member(request,id_miembro,id_grupo):
  grupo = Group.objects.get(pk=id_grupo)
  miembro = Clients.objects.get(pk=id_miembro)
  grupo.client.remove(miembro)
  redireccion = '/edit_group/' + id_grupo
  return HttpResponseRedirect(redireccion)
  

## Manda correo sin categoria e imagen.
def new_messages(request):
  list_recipes = Recipes.objects.all()
  list_users = Clients.objects.all()
  list_groups = Group.objects.all()
  list_clients = request.POST.getlist('list_clients')
  li_groups = request.POST.getlist('li_groups')  # lista de groups a la q hay q mandar el message
  if request.method == 'POST':
    formulario = NewMessagesForm(request.POST,request.FILES)
    if formulario.is_valid():
      delivery = formulario.cleaned_data['delivery_date']
      delivery_hour = formulario.cleaned_data['hour']
 
      today = datetime.now() 					# fecha actual
      dateFormat = today.strftime("%m/%d/%Y") 	# fecha con formato

      print 'Voy a enviar el mensaje \n'
      print 'recipe: ' + request.POST.get('recipes_message')
      r = Recipes.objects.get(name = request.POST.get('recipes_message'))
      titulo = 'Title mesagge'
      contenido = 'Recipe' + "\n"
      contenido += 'Name: ' + r.name + "\n"
      contenido += 'Description: ' + r.description + "\n" 

      m = NewMessages.objects.create(name_recipe=r,date=dateFormat,delivery_date=delivery,hour=delivery_hour)
  
      
      for na in li_groups:
        print 'entre en grupos'
        group = Group.objects.get(name=na)
        for g in group.client.all():
          print 'las personas en el grupo son: ' + g.name
          if g.name in list_clients:
            print 'no agregue'
          else:
            list_clients.append(g.name)
            print 'agregue'
        print na
      

      for l in list_clients:
        o = Clients.objects.get(name=l)
        a = o.email 
        correo = EmailMessage(titulo,contenido,to=[a])
        correo.send()
        m.name_user.add(o)  #Anadiendo a la lista los usuarios a los que se le van a mandar el message
        print l
      
  
      return HttpResponseRedirect('/new_message')    
  else:
    formulario = NewMessagesForm()
  return render_to_response('new_message.html',{'formulario':formulario,'list_recipes':list_recipes,'list_users':list_users,'list_groups':list_groups}, context_instance=RequestContext(request))

@login_required(login_url='/')
def inbox_all(request):
  list_inbox = MessagesReceived.objects.filter(income=True)
  return render_to_response('inbox.html',{'list_inbox':list_inbox},context_instance=RequestContext(request)) 

def inbox_see(request,id_message):
  message = MessagesReceived.objects.get(pk=id_message)
  if request.method == 'POST':
    formulario = ReplyForm(request.POST)
    if formulario.is_valid():
      mensaje = formulario.save(commit=False)
      mensaje.user = message.user
      mensaje.income = False
      today = datetime.now() 
      mensaje.date = today.strftime("%m/%d/%Y")
      mensaje.save()
  else:
    formulario = ReplyForm()
  return render_to_response('inbox_see.html',{'formulario':formulario},context_instance=RequestContext(request)) 

@login_required(login_url='/')
def messages_sent_all(request):
  list_messages_sent = NewMessages.objects.all()
  l = []
  for a in list_messages_sent:
    l.append(a.name_user.count())
    print a.name_user.count()
  p = zip(list_messages_sent,l)
  return render_to_response('messages_sent.html',{'list_messages_sent':list_messages_sent,'p':p},context_instance=RequestContext(request))   


