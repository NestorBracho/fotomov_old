#encoding:utf-8
import datetime
from django.forms import ModelForm
from django.db import models 
from django import forms
from django.contrib.auth.models import User
from post.models import *
from django.contrib.admin.widgets import AdminDateWidget 
from django.forms.extras.widgets import SelectDateWidget

class PostForm(forms.ModelForm):
  class Meta:
    model = Post
    exclude = ['fecha']

class PostEditForm(forms.Form):
  title = forms.CharField()
  post = forms.CharField(widget=forms.Textarea)
  image = forms.ImageField(required=False)

