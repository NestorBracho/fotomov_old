from django.db import models

class Post(models.Model):
  title = models.CharField(max_length=30)
  post = models.CharField(max_length=200)
  image = models.ImageField(upload_to='cargas')
  fecha = models.DateField('Date',blank=True)
# Create your models here.
