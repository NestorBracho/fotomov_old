from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext, loader
from django.contrib.auth.decorators import login_required
import datetime
from post.models import *
from post.forms import *

def create_post(request):
  lista_post = Post.objects.all()  
  if request.method == 'POST':
    formulario = PostForm(request.POST,request.FILES)
    if formulario.is_valid:
      form = formulario.save(commit=False)
      post = Post.objects.create(title=form.title,post=form.post,image=form.image,fecha=datetime.date.today())
    return HttpResponseRedirect('/post')   
  else:
    formulario = PostForm()
  return render_to_response('post.html',{'formulario':formulario,'posts':lista_post},context_instance=RequestContext(request))

def edit_post(request,id_post):
  post = Post.objects.get(id=id_post)
  lista_post = Post.objects.all()  
  if request.method == 'POST':
    formulario = PostEditForm(request.POST,request.FILES)
    if formulario.is_valid():
      print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
      if formulario.cleaned_data['image'] == None:
        post.title = formulario.cleaned_data['title']
        post.post = formulario.cleaned_data['post']
        post.fecha = datetime.date.today()
        post.save()
      else:
        post.image.delete()
        post.title = formulario.cleaned_data['title']
        post.post = formulario.cleaned_data['post']
        post.fecha = datetime.date.today()
        post.save()
        post.image = formulario.cleaned_data['image']
        post.save()

    return HttpResponseRedirect('/post')   
  else:
    formulario = PostEditForm(initial={'title':post.title,'post':post.post,'image':post.image})
  return render_to_response('edit_post.html',{'formulario':formulario,'post':post},context_instance=RequestContext(request))

def delete_post(request,id_post):
  post = Post.objects.get(id=id_post)
  post.image.delete()
  post.delete() 
  return HttpResponseRedirect('/post')   
