from django.conf.urls import patterns, include, url
from django.conf import settings
from recipe import settings
# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    url(r'^$', 'chef.views.login_page'),
    # url(r'^recipe/', include('recipe.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url('^groups/$', 'chef.views.groups'), 
	  url('^post/$', 'post.views.create_post'), 
	  url('^delete_post/(?P<id_post>\d+)$', 'post.views.delete_post'),
	  url('^edit_post/(?P<id_post>\d+)$', 'post.views.edit_post'), 
	  url('^view_group/(?P<id_group>\d+)$', 'chef.views.view_group'), 
	  url('^edit_group/(?P<id_group>\d+)$', 'chef.views.edit_group'),
    url('^delete_group_member/(?P<id_miembro>\d+)/(?P<id_grupo>\d+)$', 'chef.views.delete_group_member'), 
    url(r'^media/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.MEDIA_ROOT,}),
    url(r'^static/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.STATIC_ROOT,}),
#    url('^profile/(?P<id_cliente>\d+)$', 'chef.views.profile'),
#    ('^profile/(?P<id_cliente>\d+)$', include('gmapi.urls.media')),
    url('^address/(?P<id_cliente>\d+)$', 'chef.views.address'),
    url(r'^recipes/$', 'chef.views.recipe'),
	  url('^ingredients/$', 'chef.views.ingredientes'), 
	  url('^edit/(?P<id_item>\d+)$', 'chef.views.edit_ingredients'),
  	url(r'^allrecipes/$', 'chef.views.all_recipes'),
    url('^edit_recipes/(?P<id_item>\d+)$', 'chef.views.recipes_edit'),
    url('^recipes_delete/(?P<id_item>\d+)$', 'chef.views.recipes_delete'),
    url('^ing_delete/(?P<id_item>\d+)$', 'chef.views.ingredients_delete'),
    url(r'^clients/$', 'chef.views.clients'),
    url('^profile/(?P<id_cliente>\d+)$', 'chef.views.profile'),
    url('^address/(?P<id_cliente>\d+)$', 'chef.views.address'),
    url(r'^inbox/$', 'chef.views.inbox_all'),
    url('^inbox_see/(?P<id_message>\d+)$', 'chef.views.inbox_see'),
  	url('^new_message/$', 'chef.views.new_messages'),
  	url('^messages_sent/$', 'chef.views.messages_sent_all'),
    url('^add_group_member/(?P<id_miembro>\d+)/(?P<id_grupo>\d+)$', 'chef.views.add_group_member'), 

)
